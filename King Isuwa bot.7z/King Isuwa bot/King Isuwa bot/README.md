<div align="center">
  <img src="https://i.ibb.co/r3wmpwr/LOGO.">
  <h1>👸💎 QUEEN AMDI BOT 💎👸</h1>
</div>
<p align="center">
    Makes it easy and fun to use WhatsApp. It is also the first Sinhala user bot for WhatsApp.
    <br>
        <a href="https://chat.whatsapp.com/LYk6el7Ief41N2ypxVqcXD">Whatsapp Group</a> |
        <a href="https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ">Youtube Channel</a>
    <br>
</p>

----
<div align="center">
	<h1>Visit our official website to install the Whatsapp Bot :</h1>
	<a href="https://www.amdaniwasa.com">
<img src="https://images.squarespace-cdn.com/content/v1/580515742e69cfedd1fbef58/1525386767826-Z6T2PAXQD6PZJFNGY14U/ke17ZwdGBToddI8pDm48kGzbt7cz3CKX9Rsta-RdWeJZw-zPPgdn4jUwVcJE1ZvWQUxwkmyExglNqGp0IvTJZUJFbgE-7XRK3dMEBRBhUpwXPcCdCfJzTjuw7eD5qoJaUvNnrlJ7-JqE3xnP9OqaaXMr3zNNd3H5Lklmgn1mB80/getbutton.png" width="400"></br></a>
</div>

<p align="center">
  <a href="https://github.com/BlackAmda/QueenAmdi"><img alt="GitHub Clones" src="https://img.shields.io/badge/dynamic/json?style=flat-square&label=Docker pulls&query=count&url=https://github.com/agentnox/adadafafafaf/blob/main/automated_repo.json?raw=True&logo=github"></a>
  
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/docker/image-size/fusuf/whatsasena?style=flat-square&logo=github&label=Image Size">
    
  </a>
</p>

<p align="center">

  <a href="https://github.com/BlackAmda/QueenAmdi">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FBlackAmda%2FQueenAmdi&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi/fork">
    <img src="https://img.shields.io/github/forks/BlackAmda/QueenAmdi?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/BlackAmda/QueenAmdi/stargazers">
    <img src="https://img.shields.io/github/stars/BlackAmda/QueenAmdi?style=social">
  </a>
</p>

<p align="center">
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/repo-size/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Repo%20Size&style=plastic">

  </a>
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/license/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=License&style=plastic">

  </a>
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/github/languages/top/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="httsp://github.com/BlackAmda/QueenAmdi">
    <img src="https://img.shields.io/static/v1?label=Author&message=Black%20Amda&color=purple&style=plastic">

  </a>
  </p>
 <p align="center">
  <a href="https://wa.me/94757405652">
    <img src="https://img.shields.io/badge/Contact%20Me%20On%20Whatsapp-Queen%20Amdi%20Bot-purple&style=plastic">

  </a>
</p>

```
Queen Amdi bot is an UserBot for WhatsApp That allowing you to get done so many tasks.
The user is responsible for all possible consequences of misuse.
This is not a Open-Source project. This is just a project that allow you to get deploy a bot.
Additionally, it enables plug-in support for users.
Install their own plugins to the original software and use as they please.
Usage is entirely the responsibility of the user. The operating system is not responsible.
HAVE A FUN!
```

## Visit our official website to install the Whatsapp Bot :
QR Code generator and full instructions available there.
<div>
	<a href="https://www.amdaniwasa.com">
<img src="https://i.ibb.co/dr27VyW/59060c190cbeef0acff9a657.png" width="200"></br></a>
</div>

## Queen Amdi Team

<table>
										<tbody>
											<tr>
												<td><a href="httsp://github.com/BlackAmda/"><img src="https://amdaniwasa.com/images/AMDA.jpg" width="100" height="100" alt="Black Amda"></a></td>
												<td><a href="https://www.instagram.com/sinhalaya_official_/"><img src="https://amdaniwasa.com/images/SASMITHA.jpg" width="100" height="100" alt="sᴀsᴍɪᴛʜᴀ"></a></td>
												<td><a href="https://www.instagram.com/saji_x.x_4/"><img src="https://amdaniwasa.com/images/SAJI.jpg" width="100" height="100" alt="ʟɪʟ ʟᴜᴢɪ"></a></td>
												<td><a href="https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ"><img src="https://amdaniwasa.com/images/JOKA TAMAH.jpg" width="100" height="100" alt="ᴊᴏᴋᴀ ᴛᴀᴍᴀ"></a></td>
												<td><a href="https://dinaaofficial.github.io/dina-official/"><img src="https://amdaniwasa.com/images/DINA.jpg" width="100" height="100" alt="ᴍʀ.ᴅɪɴᴀ"></a></td>
											</tr>
											<tr>
												<td><a href="https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ">ʙʟᴀᴄᴋ ᴀᴍᴅᴀ</a></br>(Founder)</td>
												<td><a href="https://www.instagram.com/sinhalaya_official_/">sᴀsᴍɪᴛʜᴀ</a></br>(Co-Admin)</td>
												<td><a href="https://www.instagram.com/saji_x.x_4/">ʟɪʟ ʟᴜᴢɪ</a></br>(Public Supportive)</td>
												<td><a href="https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ">ᴊᴏᴋᴀ ᴛᴀᴍᴀʜ</a></br>(Web developer)</td>
												<td><a href="https://www.instagram.com/dinaa__official_/">ᴍʀ.ᴅɪɴᴀ</a></br>(Graphic Designer)</td>
										</tbody>
									</table>
                  <table>
										<tbody>
											<tr>
												<td><a href="httsp://github.com/BlackAmda/"><img src="https://amdaniwasa.com/images/KAPAYA.jpg" width="100" height="100" alt="ᴋᴀᴘᴀʏᴀ"></a></td>
												<td><a href="https://www.thinknfree.com/"><img src="https://amdaniwasa.com/images/ZEUS.jpg" width="100" height="100" alt="ᴢᴇᴜs"></a></td>
												<td><a href="httsp://github.com/BlackAmda/"><img src="https://amdaniwasa.com/images/ZEYREX.jpg" width="100" height="100" alt="ZEYREX"></a></td>
												<td><a href="httsp://github.com/BlackAmda/"><img src="https://amdaniwasa.com/images/SAIKO.jpg" width="100" height="100" alt="sɪɢᴇᴅᴇʀɪᴇɴ"></a></td>
											</tr>
											<tr>
												<td><a href="https://www.youtube.com/channel/UCZx8U1EU95-Wn9mH4dn15vQ">ᴋᴀᴘᴀʏᴀ</a></br>(Group Management)</td>
												<td><a href="https://www.thinknfree.com/">ᴢᴇᴜs</a></br>(Group Management)</td>
												<td><a href="httsp://github.com/BlackAmda/">ᴢᴇʏʀᴇX</a></br>(Ideas)</td>
												<td><a href="httsp://github.com/BlackAmda/">sɪɢᴇᴅᴇʀɪᴇɴ</a></br>(Member)</td>
										</tbody>
									</table>

### License
This project is protected by the `GNU General Public License v3.0.`
Do not edit copyright messages!

### Disclaimer
`WhatsApp` name, its variations and logo are registered trademarks on Facebook. We have nothing to do with the registered trademark.
