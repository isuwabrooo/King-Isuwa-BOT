# QueenShanali
New Repository for WhatsAsena. Also First UserBot for WhatsApp.

[![Deploy](https://dashboard.heroku.com/new?button-url)](=https%3A%2F%2Fgithub.com%2Fisuwabrooo%2FQueenShanali&template=https%3A%2F%2Fgithub.com%2Fisuwabrooo%2FQueenShanali.git)

[![Deploy]https://replit.com/@phaticusthiccy/WhatsAsena-QR
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?button-url=https%3A%2F%2Fgithub.com%2Fisuwabrooo%2FQueenShanali&template=https%3A%2F%2Fgithub.com%2Fisuwabrooo%2FQueenShanali.git)
