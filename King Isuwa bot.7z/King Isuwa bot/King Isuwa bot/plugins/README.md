# Crew Bot
</p>

```Masih testing, klo ada bug/error langsung lapor owner, scnya encrypt "Sementara"```

[*✆ contact*](https://chat.whatsapp.com/E4D1J5M7g6gCgvru8PkJKO)