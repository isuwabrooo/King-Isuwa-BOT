/* Codded by @phaticusthiccy
Telegram: t.me/phaticusthiccy
Instagram: www.instagram.com/kyrie.baran
*/

// It converts wrong commands to true
// Also Kind of AI 

const King = require('../events');
const {MessageType, GroupSettingChange} = require('@adiwajshing/baileys');

King.addCommand({pattern: 'udpate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: 'hi', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    

    await message.sendMessage('Hello!');

}));

King.addCommand({pattern: 'udpste', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: ' Udpate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

king.addCommand({pattern: ' udpate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: 'udoaye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

kin.addCommand({pattern: 'udaote', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: ' Udpaye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: ' Udpsye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: 'ypdate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: 'udpTe', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: 'udpYe', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: 'yptade', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: 'alibe', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

King.addCommand({pattern: 'aoibe', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

King.addCommand({pattern: 'aliev', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

king.addCommand({pattern: 'Alive', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

King.addCommand({pattern: ' alive', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

King.addCommand({pattern: ' Alive', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.alive');

}));

King.addCommand({pattern: 'xmedua', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

King.addCommand({pattern: 'Xmedia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

King.addCommand({pattern: 'xmesia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

King.addCommand({pattern: ' xmedia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

King.addCommand({pattern: ' Xmedia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

King.addCommand({pattern: ' Xmedua', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));

King.addCommand({pattern: 'locaye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

King.addCommand({pattern: 'lcoaye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

King.addCommand({pattern: ' locate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

King.addCommand({pattern: ' Locate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

King.addCommand({pattern: 'lcoate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.locate');

}));

King.addCommand({pattern: 'imviye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

King.addCommand({pattern: 'inviye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

King.addCommand({pattern: ' invite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

King.addCommand({pattern: ' İnvite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

King.addCommand({pattern: ' Invite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

King.addCommand({pattern: 'ingite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

King.addCommand({pattern: 'imvite', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.invite');

}));

King.addCommand({pattern: 'rstsrt', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: 'reysary', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: 'retsart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: 'resyart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: ' Restart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: ' restart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: 'resyaty', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: 'resyary', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: 'retart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: 'rwstart', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: 'resyatt', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.restart');

}));

King.addCommand({pattern: 'dyni', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.dyno');

}));

King.addCommand({pattern: 'dyjo', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.dyno');

}));

King.addCommand({pattern: ' dyno', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.dyno');

}));

King.addCommand({pattern: ' Dyno', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.dyno');

}));

King.addCommand({pattern: 'sydy', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.sysd');

}));

King.addCommand({pattern: ' sysd', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.sysd');

}));

King.addCommand({pattern: ' Sysd', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.sysd');

}));

King.addCommand({pattern: 'yagall', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.tagall');

}));

King.addCommand({pattern: ' tagall', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.tagall');

}));

King.addCommand({pattern: ' Tagall', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.tagall');

}));

King.addCommand({pattern: 'pjng', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

King.addCommand({pattern: 'ling', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

King.addCommand({pattern: 'pimg', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

King.addCommand({pattern: 'pign', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

King.addCommand({pattern: ' ping', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

King.addCommand({pattern: ' Ping', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.ping');

}));

King.addCommand({pattern: ' king', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.king');

}));

king.addCommand({pattern: ' king', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.king');

}));

King.addCommand({pattern: 'asnwa', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.King);

}));

King.addCommand({pattern: 'asnea', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('king');

}));

King.addCommand({pattern: 'asnwa', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.king');

}));

King.addCommand({pattern: 'asnwa', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('king');

}));

King.addCommand({pattern: 'ufdate', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: 'udpsye', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.update');

}));

King.addCommand({pattern: 'xemdia', fromMe: true, dontAddCommandList: true}, (async (message, match) => {
    await message.sendMessage('*🔎 Found!*');

    await message.sendMessage('.xmedia');

}));
